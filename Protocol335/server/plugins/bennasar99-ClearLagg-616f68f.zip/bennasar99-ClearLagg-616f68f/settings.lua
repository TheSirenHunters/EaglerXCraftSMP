--GENERAL--
TimeToRemove = 300
RemovePickups = true
RemoveProjectiles = true
RemoveMobs = false
--MOBLIMITER--
MaxMobsInChunk = 4
Monsters = 100
Passive = 50
Ambient = 15
Water = 15

