REPLACE INTO "PlayerSelection" (`uuid`, `MinX`, `MaxX`, `MinY`, `MaxY`, `MinZ`, `MaxZ`)
VALUES ($playeruuid, $MinX, $MaxX, $MinY, $MaxY, $MinZ, $MaxZ)