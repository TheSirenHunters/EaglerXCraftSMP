DELETE FROM "PlayerSelection"
WHERE `uuid` = $playeruuid