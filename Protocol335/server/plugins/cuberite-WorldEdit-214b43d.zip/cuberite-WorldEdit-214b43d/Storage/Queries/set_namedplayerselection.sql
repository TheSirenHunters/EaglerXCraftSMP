REPLACE INTO "NamedPlayerSelection" (`uuid`, `selname`, `MinX`, `MaxX`, `MinY`, `MaxY`, `MinZ`, `MaxZ`)
VALUES ($playeruuid, $selname, $MinX, $MaxX, $MinY, $MaxY, $MinZ, $MaxZ)