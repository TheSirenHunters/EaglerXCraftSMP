### WARNING! Only use scripts that you trust. Scripts are able to bypass the server's permission, change server settings and more.
### Anyone with the worldedit.scripting.execute permission is able to execute them.
